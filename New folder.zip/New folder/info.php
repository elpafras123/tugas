<?php

require "function.php";
php_info();
?>